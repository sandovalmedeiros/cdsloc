"""Adapters layer - ports implementations."""
