"""ORM models for all bounded contexts.

All SQLAlchemy async models representing the target data model.
Tables are organized by bounded context following hexagonal architecture.
"""

# Auth bounded context
from .auth import PasswordHash, User  # noqa: F401

# Catalog bounded context
from .catalog import (  # noqa: F401
    Cd,
    CdFisico,
    Estilo,
    Grupo,
    Interprete,
    Musica,
    Title,
)

# Customers bounded context
from .customers import (  # noqa: F401
    Bairro,
    Cliente,
    Dependente,
    Municipio,
)

# Rentals bounded context
from .rentals import (  # noqa: F401
    Locacao,
    LocacaoItem,
    Recibo,
)

# Reservations bounded context
from .reservations import (  # noqa: F401
    Reserva,
)

# Reports bounded context
from .reports import (  # noqa: F401
    Relatorio,
)

__all__ = [
    # Auth
    "User",
    "PasswordHash",
    # Catalog
    "Title",
    "Cd",
    "CdFisico",
    "Musica",
    "Interprete",
    "Grupo",
    "Estilo",
    # Customers
    "Municipio",
    "Bairro",
    "Cliente",
    "Dependente",
    # Rentals
    "Locacao",
    "LocacaoItem",
    "Recibo",
    # Reservations
    "Reserva",
    # Reports
    "Relatorio",
]
