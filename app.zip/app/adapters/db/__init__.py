"""Database adapter - SQLAlchemy repositories."""
