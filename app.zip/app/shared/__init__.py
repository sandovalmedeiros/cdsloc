"""Shared domain and infrastructure."""
